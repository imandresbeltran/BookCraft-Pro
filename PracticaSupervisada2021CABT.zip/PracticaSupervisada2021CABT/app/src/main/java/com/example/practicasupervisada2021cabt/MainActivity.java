package com.example.practicasupervisada2021cabt;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.FirebaseApp;
import com.google.firebase.firestore.FirebaseFirestore;

import java.util.HashMap;
import java.util.UUID;

public class MainActivity extends AppCompatActivity {

    private EditText mnit, mNombre, mApellido, mDireccion;
    private Button mguardarbtn, mMostrarbtn;

    private FirebaseFirestore db;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        mnit = findViewById(R.id.edit_nitcliente);
        mNombre = findViewById(R.id.edit_nombrecliente);
        mApellido = findViewById(R.id.edit_apellidoCliente);
        mDireccion = findViewById(R.id.edit_direccioncliente);
        mguardarbtn = findViewById(R.id.guardar_btn);
        mMostrarbtn = findViewById(R.id.mostrartodo_btn);
        db = FirebaseFirestore.getInstance();

        mMostrarbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(MainActivity.this, MostrarClientes.class));
            }
        });

        mguardarbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String identificacion = mnit.getText().toString();
                String nombre = mNombre.getText().toString();
                String apellido = mApellido.getText().toString();
                String direccion = mDireccion.getText().toString();

                String id = UUID.randomUUID().toString();

                saveToFireStrore(id, identificacion, nombre, apellido, direccion);

                LimpiarCajas();
            }
        });

    }

    private void LimpiarCajas(){
        mnit.setText("");
        mNombre.setText("");
        mApellido.setText("");
        mDireccion.setText("");
        mnit.requestFocus();
    }

    private void saveToFireStrore(String id, String identificacion, String nombre, String apellido, String direccion) {
        if (!identificacion.isEmpty() && !nombre.isEmpty() && !apellido.isEmpty() && !direccion.isEmpty()) {
            HashMap<String, Object> map = new HashMap<>();
            map.put("id", id);
            map.put("identificacion", identificacion);
            map.put("nombre", nombre);
            map.put("apellido", apellido);
            map.put("direccion", direccion);

            db.collection("clientes").document(id).set(map).addOnCompleteListener(new OnCompleteListener<Void>() {
                @Override
                public void onComplete(@NonNull Task<Void> task) {
                    if (task.isSuccessful()) {
                        Toast.makeText(MainActivity.this, "Cliente Registrado", Toast.LENGTH_SHORT).show();
                    }
                }
            }).addOnFailureListener(new OnFailureListener() {
                @Override
                public void onFailure(@NonNull Exception e) {
                    Toast.makeText(MainActivity.this, "Error!!", Toast.LENGTH_SHORT).show();
                }
            });

        }else {
            Toast.makeText(this, "Por favor, llene todos los campos", Toast.LENGTH_SHORT).show();
        }
    }
}