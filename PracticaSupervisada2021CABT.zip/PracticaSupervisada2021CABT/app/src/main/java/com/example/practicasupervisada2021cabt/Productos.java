package com.example.practicasupervisada2021cabt;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.firestore.FirebaseFirestore;

import java.util.HashMap;
import java.util.UUID;

public class Productos extends AppCompatActivity {

    private EditText mCodigo, mNombre, mDescripcion, mMarca, mExistencias, mPrecio;
    private Button mGuardarPRbtn, mmostrarPRbtn;

    private FirebaseFirestore db;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_productos);

        mCodigo = findViewById(R.id.edit_correlativo);
        mNombre = findViewById(R.id.edit_nombreproducto);
        mDescripcion = findViewById(R.id.edit_descripcionproducto);
        mMarca = findViewById(R.id.edit_marcaproducto);
        mExistencias = findViewById(R.id.edit_existenciasproducto);
        mPrecio = findViewById(R.id.edit_precioproducto);

        db = FirebaseFirestore.getInstance();

        mGuardarPRbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String identificacion = mCodigo.getText().toString();
                String nombre = mNombre.getText().toString();
                String Descripcion = mDescripcion.getText().toString();
                String Marca = mMarca.getText().toString();
                String Existencias = mExistencias.getText().toString();
                String Precio = mPrecio.getText().toString();

                String id = UUID.randomUUID().toString();

                saveToFireStrore(id, identificacion, nombre, Descripcion, Marca, Existencias, Precio);
            }
        });
    }

    private void saveToFireStrore(String id, String identificacion, String nombre, String Descripcion, String Marca, String Existencias, String Precio) {
        if (!identificacion.isEmpty() && !nombre.isEmpty() && !Descripcion.isEmpty() && !Marca.isEmpty() && !Existencias.isEmpty() && !Precio.isEmpty()){
            HashMap<String, Object> map = new HashMap<>();
            map.put("id", id);
            map.put("identificacion", identificacion);
            map.put("nombre", nombre);
            map.put("descripcion", Descripcion);
            map.put("marca", Marca);
            map.put("existencias", Existencias);
            map.put("precio", Precio);

            db.collection("productos").document(id).set(map).addOnCompleteListener(new OnCompleteListener<Void>() {
                @Override
                public void onComplete(@NonNull Task<Void> task) {
                    if (task.isSuccessful()) {
                        Toast.makeText(Productos.this, "Producto Registrado", Toast.LENGTH_SHORT).show();
                    }
                }
            }).addOnFailureListener(new OnFailureListener() {
                @Override
                public void onFailure(@NonNull Exception e) {
                    Toast.makeText(Productos.this, "Error!!", Toast.LENGTH_SHORT).show();
                }
            });

        }else {
            Toast.makeText(this, "Por favor, llene todos los campos", Toast.LENGTH_SHORT).show();
        }
    }

}