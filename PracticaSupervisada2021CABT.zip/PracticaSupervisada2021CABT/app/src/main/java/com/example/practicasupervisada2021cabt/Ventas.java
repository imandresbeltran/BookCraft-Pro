package com.example.practicasupervisada2021cabt;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.firestore.FirebaseFirestore;

import java.util.HashMap;
import java.util.UUID;

public class Ventas extends AppCompatActivity {

    private EditText mFechaVenta, mCodigoVenta;
    private Button mGuardarVbtn, mmostrarVbtn;

    private FirebaseFirestore db;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ventas);

        mFechaVenta = findViewById(R.id.edit_fechadeventa);
        mCodigoVenta = findViewById(R.id.edit_codigoventa);

        db = FirebaseFirestore.getInstance();

        mGuardarVbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String identificacion = mFechaVenta.getText().toString();
                String codigoventa = mCodigoVenta.getText().toString();

                String id = UUID.randomUUID().toString();

                saveToFireStrore(id, identificacion, codigoventa);
            }
        });
    }
    private void saveToFireStrore(String id, String identificacion, String codigoventa) {
        if (!identificacion.isEmpty() && !codigoventa.isEmpty()){
            HashMap<String, Object> map = new HashMap<>();
            map.put("id", id);
            map.put("identificacion", identificacion);
            map.put("codigoventa", codigoventa);

            db.collection("Ventas").document(id).set(map).addOnCompleteListener(new OnCompleteListener<Void>() {
                @Override
                public void onComplete(@NonNull Task<Void> task) {
                    if (task.isSuccessful()) {
                        Toast.makeText(Ventas.this, "Venta Registrada", Toast.LENGTH_SHORT).show();
                    }
                }
            }).addOnFailureListener(new OnFailureListener() {
                @Override
                public void onFailure(@NonNull Exception e) {
                    Toast.makeText(Ventas.this, "Error!!", Toast.LENGTH_SHORT).show();
                }
            });

        }else {
            Toast.makeText(this, "Por favor, llene todos los campos", Toast.LENGTH_SHORT).show();
        }
    }

}