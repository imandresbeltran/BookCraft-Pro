package com.example.practicasupervisada2021cabt;

import android.graphics.ColorSpace;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class MyAdapter extends RecyclerView.Adapter<MyAdapter.MyViewHolder> {

    private MostrarClientes activity;
    private List<ModelClientes> mList;

    public MyAdapter(MostrarClientes activity, List<ModelClientes> mList) {
        this.activity = activity;
        this.mList = mList;
    }

    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(activity).inflate(R.layout.item, parent, false);
        return new MyViewHolder(v);
    }

    @Override
    public void onBindViewHolder(@NonNull MyViewHolder holder, int position) {
        holder.nit.setText(mList.get(position).getNit());
        holder.nombre.setText(mList.get(position).getNombre());
        holder.apellido.setText(mList.get(position).getApellido());
        holder.direccion.setText(mList.get(position).getDireccion());
    }

    @Override
    public int getItemCount() {
        return mList.size();
    }

    public static class MyViewHolder extends RecyclerView.ViewHolder{


        TextView nit, nombre, apellido, direccion;

        public MyViewHolder(@NonNull View itemView) {
            super(itemView);

            nit = itemView.findViewById(R.id.title_nit);
            nombre = itemView.findViewById(R.id.title_nombre);
            apellido = itemView.findViewById(R.id.title_apellido);
            direccion = itemView.findViewById(R.id.title_direccion);
        }
    }
}
