package com.example.practicasupervisada2021cabt;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.firestore.FirebaseFirestore;

import java.util.HashMap;
import java.util.UUID;

public class Proveedores extends AppCompatActivity {

    private EditText mCodigo, mNombre, mDireccionP, mTelefono, mEmail, mRepresentanteP, mTelefonoRP, mRepresentanteVentas;
    private Button mGuardarbtn, mmostrarbtn;

    private FirebaseFirestore db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_proveedores);

        mCodigo = findViewById(R.id.edit_codigoproveedor);
        mNombre = findViewById(R.id.edit_nombreproveedor);
        mDireccionP = findViewById(R.id.edit_direccionproveedor);
        mTelefono = findViewById(R.id.edit_telefonoproveedor);
        mEmail = findViewById(R.id.edit_emailproveedor);
        mRepresentanteP = findViewById(R.id.edit_representanteproveedor);
        mTelefonoRP = findViewById(R.id.edi_telefonorepresentanteproveedor);
        mRepresentanteVentas = findViewById(R.id.edit_representanteventasp);

        db = FirebaseFirestore.getInstance();

        mGuardarbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String identificacion = mCodigo.getText().toString();
                String nombre = mNombre.getText().toString();
                String DireccionP = mDireccionP.getText().toString();
                String Telefono = mTelefono.getText().toString();
                String Email = mEmail.getText().toString();
                String RepresentanteP = mRepresentanteP.getText().toString();
                String  TelefonoRP = mTelefonoRP.getText().toString();
                String RepresentanteVP = mRepresentanteVentas.getText().toString();

                String id = UUID.randomUUID().toString();

                saveToFireStrore(id, identificacion, nombre, DireccionP, Telefono, Email, RepresentanteP, TelefonoRP, RepresentanteVP);
            }
        });

    }

    private void saveToFireStrore(String id, String identificacion, String nombre, String DireccionP, String Telefono, String Email, String RepresentanteP, String TelefonoRP, String RepresentateVP) {
        if (!identificacion.isEmpty() && !nombre.isEmpty() && !DireccionP.isEmpty() && !Telefono.isEmpty() && !Email.isEmpty() && !RepresentanteP.isEmpty() && !TelefonoRP.isEmpty() && !RepresentateVP.isEmpty()){
            HashMap<String, Object> map = new HashMap<>();
            map.put("id", id);
            map.put("identificacion", identificacion);
            map.put("nombre", nombre);
            map.put("direccion", DireccionP);
            map.put("telefono", Telefono);
            map.put("email", Email);
            map.put("representanteproveedor", RepresentanteP);
            map.put("telefonorepresentanteproveedor", TelefonoRP);
            map.put("representanteventas", RepresentateVP);

            db.collection("Proveedor").document(id).set(map).addOnCompleteListener(new OnCompleteListener<Void>() {
                @Override
                public void onComplete(@NonNull Task<Void> task) {
                    if (task.isSuccessful()) {
                        Toast.makeText(Proveedores.this, "Proveedor Registrado", Toast.LENGTH_SHORT).show();
                    }
                }
            }).addOnFailureListener(new OnFailureListener() {
                @Override
                public void onFailure(@NonNull Exception e) {
                    Toast.makeText(Proveedores.this, "Error!!", Toast.LENGTH_SHORT).show();
                }
            });

        }else {
            Toast.makeText(this, "Por favor, llene todos los campos", Toast.LENGTH_SHORT).show();
        }
    }

}