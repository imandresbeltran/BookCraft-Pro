package com.example.practicasupervisada2021cabt;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.firestore.FirebaseFirestore;

import java.util.HashMap;
import java.util.UUID;

public class Empleados extends AppCompatActivity {

    private EditText mCarne, mNombre, mApellido, mDireccion, mFechaNacimiento, mFechaIngresoTrabjo, mTelefono, mTelefonoCasa;
    private Button mGuardarEbtn, mmostrarEbtn;

    private FirebaseFirestore db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_empleados);

        mCarne = findViewById(R.id.edit_igssempleado);
        mNombre = findViewById(R.id.edit_nombreempleado);
        mApellido = findViewById(R.id.edit_apellidoempleado);
        mDireccion = findViewById(R.id.edit_direccionempleado);
        mFechaNacimiento = findViewById(R.id.edit_fechanempleado);
        mFechaIngresoTrabjo = findViewById(R.id.edit_fechaiempleado);
        mTelefono = findViewById(R.id.edit_telefonoempleado);
        mTelefonoCasa = findViewById(R.id.edit_telefonocasaempleado);

        db = FirebaseFirestore.getInstance();

        mGuardarEbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String identificacion = mCarne.getText().toString();
                String nombre = mNombre.getText().toString();
                String Apellido = mApellido.getText().toString();
                String Direccion = mDireccion.getText().toString();
                String FechaNacimiento = mFechaNacimiento.getText().toString();
                String FechaIngreso = mFechaIngresoTrabjo.getText().toString();
                String TelefonoE = mTelefono.getText().toString();
                String TelefonoCasa = mTelefonoCasa.getText().toString();

                String id = UUID.randomUUID().toString();

                saveToFireStrore(id, identificacion, nombre, Apellido, Direccion, FechaNacimiento, FechaIngreso, TelefonoE, TelefonoCasa);
            }
        });

    }
    private void saveToFireStrore(String id, String identificacion, String nombre, String Apellido, String Direccion, String FechaNacimiento, String FechaIngreso, String TelefonoE, String TelefonoCasa) {
        if (!identificacion.isEmpty() && !nombre.isEmpty() && !Apellido.isEmpty() && !Direccion.isEmpty() && !FechaNacimiento.isEmpty() && !FechaIngreso.isEmpty() && !TelefonoE.isEmpty() && !TelefonoCasa.isEmpty()){
            HashMap<String, Object> map = new HashMap<>();
            map.put("id", id);
            map.put("identificacion", identificacion);
            map.put("nombre", nombre);
            map.put("apellido", Apellido);
            map.put("direccion", Direccion);
            map.put("fechanacimiento", FechaNacimiento);
            map.put("fechaingreso", FechaIngreso);
            map.put("telefono", TelefonoE);
            map.put("telefonocasa", TelefonoCasa);

            db.collection("Empleado").document(id).set(map).addOnCompleteListener(new OnCompleteListener<Void>() {
                @Override
                public void onComplete(@NonNull Task<Void> task) {
                    if (task.isSuccessful()) {
                        Toast.makeText(Empleados.this, "Empleado Registrado", Toast.LENGTH_SHORT).show();
                    }
                }
            }).addOnFailureListener(new OnFailureListener() {
                @Override
                public void onFailure(@NonNull Exception e) {
                    Toast.makeText(Empleados.this, "Error!!", Toast.LENGTH_SHORT).show();
                }
            });

        }else {
            Toast.makeText(this, "Por favor, llene todos los campos", Toast.LENGTH_SHORT).show();
        }
    }

}